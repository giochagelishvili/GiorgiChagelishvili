﻿namespace Practice_1
{
    public abstract class Shape
    {
        public abstract double Perimeter();
        public abstract double Area();
    }
}
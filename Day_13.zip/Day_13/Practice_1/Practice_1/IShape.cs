﻿namespace Practice_1
{
    interface IShape
    {
        double Perimeter();
        double Area();
    }
}

﻿namespace ChessBasics
{
    public class Board
    {
        private const int Rows = 8;
        private const int Columns = 8;


    }
}
